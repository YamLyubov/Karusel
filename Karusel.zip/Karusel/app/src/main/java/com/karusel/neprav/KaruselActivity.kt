package com.karusel.neprav

import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.DiffUtil
import com.google.gson.GsonBuilder
import com.yuyakaido.android.cardstackview.*
import okhttp3.*
import org.json.JSONException
import java.io.IOException
import java.util.*

class KaruselActivity : AppCompatActivity(), CardStackListener {

    private val drawerLayout by lazy { findViewById<DrawerLayout>(R.id.drawer_layout) }
    private val cardStackView by lazy { findViewById<CardStackView>(R.id.card_stack_view) }
    private val manager by lazy { CardStackLayoutManager(this, this) }
    private val adapter by lazy { CardStackAdapter(createTopics()) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_karusel)
        setupCardStackView()
        setupButton()
        var topics = adapter.getTopics()
    }

    override fun onCardDragging(direction: Direction, ratio: Float) {
        Log.d("CardStackView", "onCardDragging: d = ${direction.name}, r = $ratio")
    }

    override fun onCardSwiped(direction: Direction) {
        Log.d("CardStackView", "onCardSwiped: p = ${manager.topPosition}, d = $direction")
        if (direction.toString()=="Right"&& adapter.getTopics()[manager.topPosition].intent == "DISCUSS"){
            Toast.makeText(this, "New conversation", Toast.LENGTH_SHORT).show()
        }
        if (direction.toString()=="Left"&& adapter.getTopics()[manager.topPosition].intent == "ARGUE"){
            Toast.makeText(this, "New conversation", Toast.LENGTH_SHORT).show()
        }
        //подгружаем топики
        if (manager.topPosition == adapter.itemCount - 5) {
            paginate()
        }
    }

    override fun onCardRewound() {
        Log.d("CardStackView", "onCardRewound: ${manager.topPosition}")
    }

    override fun onCardCanceled() {
        Log.d("CardStackView", "onCardCanceled: ${manager.topPosition}")
    }

    override fun onCardAppeared(view: View, position: Int) {
        val textView = view.findViewById<TextView>(R.id.topicTextView)
        Log.d("CardStackView", "onCardAppeared: ($position) ${textView.text}")
    }

    override fun onCardDisappeared(view: View, position: Int) {
        val textView = view.findViewById<TextView>(R.id.topicTextView)
        Log.d("CardStackView", "onCardDisappeared: ($position) ${textView.text}")
    }



    private fun setupCardStackView() {
        initialize()
    }

    private fun setupButton() {
        val skip = findViewById<View>(R.id.skip_button)
        skip.setOnClickListener {
            val setting = SwipeAnimationSetting.Builder()
                .setDirection(Direction.Left)
                .setDuration(Duration.Normal.duration)
                .setInterpolator(AccelerateInterpolator())
                .build()
            manager.setSwipeAnimationSetting(setting)
            cardStackView.swipe()
        }

        val rewind = findViewById<View>(R.id.rewind_button)
        rewind.setOnClickListener {
            val setting = RewindAnimationSetting.Builder()
                .setDirection(Direction.Bottom)
                .setDuration(Duration.Normal.duration)
                .setInterpolator(DecelerateInterpolator())
                .build()
            manager.setRewindAnimationSetting(setting)
            cardStackView.rewind()
        }

        val like = findViewById<View>(R.id.like_button)
        like.setOnClickListener {
            val setting = SwipeAnimationSetting.Builder()
                .setDirection(Direction.Right)
                .setDuration(Duration.Normal.duration)
                .setInterpolator(AccelerateInterpolator())
                .build()
            manager.setSwipeAnimationSetting(setting)
            cardStackView.swipe()
        }
    }

    private fun initialize() {
        manager.setStackFrom(StackFrom.None)
        manager.setVisibleCount(3)
        manager.setTranslationInterval(8.0f)
        manager.setScaleInterval(0.95f)
        manager.setSwipeThreshold(0.3f)
        manager.setMaxDegree(20.0f)
        manager.setDirections(Direction.FREEDOM)
        manager.setCanScrollHorizontal(true)
        manager.setCanScrollVertical(true)
        manager.setSwipeableMethod(SwipeableMethod.Manual)
        manager.setOverlayInterpolator(LinearInterpolator())
        cardStackView.layoutManager = manager
        cardStackView.adapter = adapter
        cardStackView.itemAnimator.apply {
            if (this is DefaultItemAnimator) {
                supportsChangeAnimations = false
            }
        }
    }


    //подгрузка топиков
    private fun paginate() {
        val old = adapter.getTopics()
        val new = old.plus(createTopics())
        val callback = TopicDiffCallback(old, new)
        val result = DiffUtil.calculateDiff(callback)
        adapter.setTopics(new)
        result.dispatchUpdatesTo(adapter)
    }

    private fun reload() {
        val old = adapter.getTopics()
        val new = createTopics()
        val callback = TopicDiffCallback(old, new)
        val result = DiffUtil.calculateDiff(callback)
        adapter.setTopics(new)
        result.dispatchUpdatesTo(adapter)
    }

    private fun addFirst(size: Int) {
        val old = adapter.getTopics()
        val new = mutableListOf<Topic>().apply {
            addAll(old)
            for (i in 0 until size) {
                add(manager.topPosition, createTopic())
            }
        }
        val callback = TopicDiffCallback(old, new)
        val result = DiffUtil.calculateDiff(callback)
        adapter.setTopics(new)
        result.dispatchUpdatesTo(adapter)
    }

    private fun addLast(size: Int) {
        val old = adapter.getTopics()
        val new = mutableListOf<Topic>().apply {
            addAll(old)
            addAll(List(size) { createTopic() })
        }
        val callback = TopicDiffCallback(old, new)
        val result = DiffUtil.calculateDiff(callback)
        adapter.setTopics(new)
        result.dispatchUpdatesTo(adapter)
    }

    private fun removeFirst(size: Int) {
        if (adapter.getTopics().isEmpty()) {
            return
        }

        val old = adapter.getTopics()
        val new = mutableListOf<Topic>().apply {
            addAll(old)
            for (i in 0 until size) {
                removeAt(manager.topPosition)
            }
        }
        val callback = TopicDiffCallback(old, new)
        val result = DiffUtil.calculateDiff(callback)
        adapter.setTopics(new)
        result.dispatchUpdatesTo(adapter)
    }

    private fun removeLast(size: Int) {
        if (adapter.getTopics().isEmpty()) {
            return
        }

        val old = adapter.getTopics()
        val new = mutableListOf<Topic>().apply {
            addAll(old)
            for (i in 0 until size) {
                removeAt(this.size - 1)
            }
        }
        val callback = TopicDiffCallback(old, new)
        val result = DiffUtil.calculateDiff(callback)
        adapter.setTopics(new)
        result.dispatchUpdatesTo(adapter)
    }

    private fun replace() {
        val old = adapter.getTopics()
        val new = mutableListOf<Topic>().apply {
            addAll(old)
            removeAt(manager.topPosition)
            add(manager.topPosition, createTopic())
        }
        adapter.setTopics(new)
        adapter.notifyItemChanged(manager.topPosition)
    }

    private fun swap() {
        val old = adapter.getTopics()
        val new = mutableListOf<Topic>().apply {
            addAll(old)
            val first = removeAt(manager.topPosition)
            val last = removeAt(this.size - 1)
            add(manager.topPosition, last)
            add(first)
        }
        val callback = TopicDiffCallback(old, new)
        val result = DiffUtil.calculateDiff(callback)
        adapter.setTopics(new)
        result.dispatchUpdatesTo(adapter)
    }

    private fun createTopic(): Topic {
        return Topic(
            id = 0,
            date_create = "06.05.12",
            intent = "DISCUSS",
            text = "number one",
            user_id = 111
        )
    }

    private fun createTopics(): List<Topic> {
        val body = "{'total': 100,'next_page': 101,'data':[{'id': 1,'date_create':'05.06.20', intent':'ARGUE','text':'PUTIN 407','user_id':123},{'id': 2,'date_create':'05.06.20','intent':'ARGUE','text':'PUTIN 408','user_id':124},{'id': 3,'date_create':'05.06.20','intent':'ARGUE','text':'PUTIN 409','user_id':125},{'id': 4,'date_create':'05.06.20','intent':'ARGUE','text':'PUTIN 410','user_id':126},{'id': 5,'date_create':'05.06.20','intent':'ARGUE','text':'PUTIN 411','user_id':127},{'id': 6,'date_create':'05.06.20','intent':'ARGUE','text':'PUTIN 412','user_id':128}]}"
        val gson = GsonBuilder().create()
        var topics = gson.fromJson(body, Topics::class.java)
        return topics.data
//        val spots = ArrayList<Spot>()
//        spots.add(Spot(name = "Yasaka Shrine", city = "Kyoto", url = "https://source.unsplash.com/Xq1ntWruZQI/600x800"))
//        spots.add(Spot(name = "Fushimi Inari Shrine", city = "Kyoto", url = "https://source.unsplash.com/NYyCqdBOKwc/600x800"))
//        spots.add(Spot(name = "Bamboo Forest", city = "Kyoto", url = "https://source.unsplash.com/buF62ewDLcQ/600x800"))
//        spots.add(Spot(name = "Brooklyn Bridge", city = "New York", url = "https://source.unsplash.com/THozNzxEP3g/600x800"))
//        spots.add(Spot(name = "Empire State Building", city = "New York", url = "https://source.unsplash.com/USrZRcRS2Lw/600x800"))
//        spots.add(Spot(name = "The statue of Liberty", city = "New York", url = "https://source.unsplash.com/PeFk7fzxTdk/600x800"))
//        spots.add(Spot(name = "Louvre Museum", city = "Paris", url = "https://source.unsplash.com/LrMWHKqilUw/600x800"))
//        spots.add(Spot(name = "Eiffel Tower", city = "Paris", url = "https://source.unsplash.com/HN-5Z6AmxrM/600x800"))
//        spots.add(Spot(name = "Big Ben", city = "London", url = "https://source.unsplash.com/CdVAUADdqEc/600x800"))
//        spots.add(Spot(name = "Great Wall of China", city = "China", url = "https://source.unsplash.com/AWh9C-QjhE4/600x800"))
//        return spots
    }

}
    fun getTopics(){
        val url = "http://127.0.0.1:5000/api/topics"

        val request = Request.Builder().url(url).build()

        val client = OkHttpClient()

        client.newCall(request).enqueue(object: Callback {
            override fun onFailure(call: Call, e: IOException) {
                println("Failed to execute request ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string()
                println("Connected $body")
                try {
                    val gson = GsonBuilder().create()
                    val new_topics = gson.fromJson(body, Topics::class.java)
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            }
        })


//    fun startConversation(){
//        Log.d("Karusel", "Open conversation")
//        Toast.makeText(this, "New conversation", Toast.LENGTH_SHORT).show()
//    }
}
class Topics(val total: Int, val next_page: Int, val data: List<Topic>)

class Topic(val id: Int,val date_create: String, val intent: String,val text: String, val user_id: Int)
